{\rtf1\ansi\ansicpg1252\cocoartf2870
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fswiss\fcharset0 Helvetica-Oblique;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;}
\paperw11900\paperh16840\margl1440\margr1440\vieww34000\viewh21460\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\sl360\slmult1\pardirnatural\partightenfactor0

\f0\fs36 \cf0 Query 1: List all customers from Germany:\
\

\fs32 SELECT *\
FROM Customer\
WHERE Country = 'Germany';\

\fs36 \
Query 2: List tracks costing more than $1:\
\

\fs32 SELECT Name, UnitPrice\
FROM Track\
WHERE UnitPrice > 1;\

\fs36 \
Query 3: Sort customers by last name:\
\

\fs32 SELECT FirstName, LastName\
FROM Customer\
ORDER BY LastName;\

\fs36 \
Query 4: Count customers in each country:\
\

\fs32 SELECT Country, COUNT(*) AS TotalCustomers\
FROM Customer\
GROUP BY Country;
\fs36 \
\
Query 5: Average invoice amount by customer:\
\

\fs32 SELECT CustomerId, AVG(Total) AS AvgInvoice\
FROM Invoice\
GROUP BY CustomerId;\
\
\pard\pardeftab720\sl360\slmult1\partightenfactor0

\fs36 \cf0 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 Query 6: Countries with more than 5 customers:\
\
\pard\pardeftab720\sl360\slmult1\partightenfactor0

\fs32 \cf0 SELECT Country, COUNT(
\f1\i ) AS TotalCustomers\uc0\u8232 FROM Customer\u8232 GROUP BY Country\u8232 HAVING COUNT(
\f0\i0 ) > 5;\
\
\pard\pardeftab720\sl360\slmult1\partightenfactor0

\fs36 \cf0 Query 7: Customer names and invoice totals:\
\pard\pardeftab720\sl360\slmult1\partightenfactor0

\fs32 \cf0 \
SELECT Customer.FirstName,\uc0\u8232 Customer.LastName,\u8232 Invoice.Total\u8232 FROM Customer\u8232 INNER JOIN Invoice\u8232 ON Customer.CustomerId = Invoice.CustomerId;\
\
\pard\pardeftab720\sl360\slmult1\partightenfactor0

\fs36 \cf0 Query 8: Track names and album titles:
\fs32 \
\
SELECT Track.Name,\uc0\u8232 Album.Title\u8232 FROM Track\u8232 INNER JOIN Album\u8232 ON Track.AlbumId = Album.AlbumId;\
\

\fs36 Query 9: All customers and their invoices:\
\pard\pardeftab720\sl360\slmult1\partightenfactor0

\fs32 \cf0 \
SELECT Customer.FirstName,\uc0\u8232 Customer.LastName,\u8232 Invoice.InvoiceId\u8232 FROM Customer\u8232 LEFT JOIN Invoice\u8232 ON Customer.CustomerId = Invoice.CustomerId;\
\
\pard\pardeftab720\sl360\slmult1\partightenfactor0

\fs36 \cf0 Query 10: Tracks priced above average:
\fs32 \
\
SELECT Name, UnitPrice\uc0\u8232 FROM Track\u8232 WHERE UnitPrice >\u8232 (\u8232 SELECT AVG(UnitPrice)\u8232 FROM Track\u8232 );\
\

\fs36 SQL Murder Mystery Solution:
\fs32 \
\
SELECT *\
FROM person\
WHERE name = 'Jeremy Bowers';}